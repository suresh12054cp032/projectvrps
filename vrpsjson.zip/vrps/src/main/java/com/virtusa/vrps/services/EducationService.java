package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.repositories.EducationRepo;

@Service
public class EducationService {
	@Autowired
	private EducationRepo educationRepo;
	
	public Education saveEducation(Education education)
	{
		return educationRepo.save(education);
	}
	
	public Education findByEducationId(int educationId)
	{
		return educationRepo.findById(educationId).orElse(null);
	}

}
