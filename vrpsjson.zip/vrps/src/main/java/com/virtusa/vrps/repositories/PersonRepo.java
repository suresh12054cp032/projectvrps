package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.virtusa.shopping.models.Category;
import com.virtusa.vrps.models.Person;

//import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;

public interface PersonRepo extends JpaRepository<Person,Integer>{

}