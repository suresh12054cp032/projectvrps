package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.Personal;

public interface PersonalRepo  extends JpaRepository<Personal, Integer> {

}
