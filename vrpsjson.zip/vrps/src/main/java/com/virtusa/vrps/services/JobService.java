package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.repositories.JobRepo;

@Service
public class JobService {

	@Autowired
	private JobRepo jobRepo;
	
}
