package com.virtusa.vrps.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.vrps.models.Company;
import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class CreateProfileController {

	@Autowired
	private PersonalService personalService;

	@Autowired
	private WorkService workService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private EducationService educationService;

	@PostMapping("/saveEduDetails")
	public void savePersonal(@ModelAttribute Personal objpersonal,Work objwork, Model model) {
		
		model.addAttribute("personal", personalService.savePersonal(objpersonal));
		model.addAttribute("work", workService.saveWork(objwork));

		System.out.println(objpersonal+","+objwork);

	}

	@PostMapping("/saveWork")
	public void saveWork(@ModelAttribute Work work, Model model) {
		model.addAttribute("work", workService.saveWork(work));

	}

	@PostMapping("/saveCompany")
	public void saveCompany(@ModelAttribute Company	company, 
			Model model)
	{
		model.addAttribute("company", companyService.saveCompany(company));	
	}

	/*
	 * @PostMapping("/saveEducation") public String
	 * saveWork(@ModelAttribute("Education") , Model model) {
	 * model.addAttribute("work", workService.saveWork(work));
	 * 
	 * return "addproduct";
	 * 
	 * }
	 */
	
	
	
	
	
}
