var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
    // This function will display the specified tab of the form...
	 x = document.getElementsByClassName("tab");
    x[n].style.display = "block";
    //... and fix the Previous/Next buttons:
    if (n == 0) {
        document.getElementById("prevBtn").style.display = "none";
    } else {
        document.getElementById("prevBtn").style.display = "inline";
    }
    if (n == (x.length - 1)) {
        document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
        document.getElementById("nextBtn").innerHTML = "save&Next";
    }
    //... and run a function that will display the correct step indicator:
    fixStepIndicator(n);
}



function addEducation()
{
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByTagName("input");
    var course = y["course"].value;
    var branch = y["branch"].value;
    var institutionName = y["institutionName"].value;
    var passYear = y["passYear"].value;
    var percentage = y["percentage"].value;
    if(stringLengthAndEmpty(course))
    {
        y["course"].className += "invalid";
        valid=false;
    }
    else
    {
        y["course"].className += "valid";
    }
    if(stringLengthAndEmpty(institutionName))
    {
        y["institutionName"].className += "invalid";
        valid=false;
    }
    else
    {
        y["institutionName"].className += "valid";
    }
    if(numberLength(percentage) )
    {
        y["percentage"].className += "invalid";
        valid=false;
    }
    else
    {
        y["percentage"].className += "valid";
    }
    if(isYear(passYear))
    {
        y["passYear"].className += "invalid";
        valid=false;
    }
    else
    {
        y["passYear"].className += "valid";
    }


}
function addCompany()
{
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByTagName("input");
    var companyName = y["companyName"].value;
    var designation =y["designation"].value;
    var startDate = y["startDate"].value;
    var endDate =y["endDate"].value;
    var package = y["previousPackage"].value;
    var technologies = y["technologiesWorked"].value;
    if(stringLengthAndEmpty(companyName))
    {
        y["companyName"].className += "invalid";
        valid=false;
    }
    else
    {
        y["companyName"].className += "valid";
    }
    if(stringLengthAndEmpty(designation))
    {
        y["designation"].className += "invalid";
        valid=false;
    }
    else
    {
        y["designation"].className += "valid";
    }
    if(stringLengthAndEmpty(technologies))
    {
        y["technologiesWorked"].className += "invalid";
        valid=false;
    }
    else
    {
        y["technologiesWorked"].className += "valid";
    }
    if(isFutureDate(startDate) || startDate.length==0)
    {
        y["startDate"].className += "invalid";
        valid=false;
    }
    else
    {
        y["startDate"].className += "valid";
    }
    if(isEdLtSd(startDate,endDate) || endDate=="")
    {
        y["endDate"].className += "invalid";
        valid=false;
    }
    else
    {
        y["endDate"].className += "valid";
    }
  
}



function nextPrev(n) {
    // This function will figure out which tab to display


    var x = document.getElementsByClassName("tab");
    // Exit the function if any field in the current tab is invalid:
    if (n == 1 && !validateForm()) return false;
    // Hide the current tab:
    x[currentTab].style.display = "none";
    // Increase or decrease the current tab by 1:
    currentTab = currentTab + n;
    // if you have reached the end of the form...
    if (currentTab >= x.length) {
        // ... the form gets submitted:
        document.getElementById("regForm").submit();
        return false;
    }
    // Otherwise, display the correct tab:
    showTab(currentTab);
}

function validateForm() {
    // This function deals with validation of the form fields
    var x, y, i, valid = true;
    x = document.getElementsByClassName("tab");
    y = x[currentTab].getElementsByTagName("input");
    // A loop that checks every input field in the current tab:

    if(currentTab==0)
    {
         var fullName = y["name"].value;

         var mobile = y["mobile"].value;

         var dob =y["dob"].value;

         var email = y["email"].value;

         if(stringLengthAndEmpty(fullName))
         {
             y["name"].className += "invalid";
             valid=false;
         }
         else
         {
             y["name"].className += "valid";
         }

         if(mobile.length!=10 || isNaN(mobile))
         {
             y["mobile"].className += "invalid";
             valid=false;
         }
         else
         {
             y["mobile"].className += "valid";
         }

         if(isFutureDate(dob) || dob=="")
         {
             y["dob"].className += "invalid";
             valid =false;

         }
         else
         {
             y["dob"].className += "valid";
         }

         if(!validateEmail(email))
         {
             y["email"].className += "invalid";
             valid =false;
         }
         else
         {
             y["email"].className += "valid";
         }

    }

    /*for (i = 0; i < y.length; i++) {
      // If a field is empty...
      if (y[i].value == "") {
        // add an "invalid" class to the field:
        y[i].className += " invalid";
        // and set the current valid status to false
        valid = false;
      }
    }*/

    if(currentTab==1)
    {

         var designation=y["designation"].value;

         var experience=y["experience"].value;
         var skills = y["skills"].value;


         if(numberLength(experience))
         {
             y["experience"].className += "invalid";
             valid=false;
         }
         else
         {
             y["experience"].className += "valid";
         }
         if(stringLengthAndEmpty(skills))
         {
             y["skills"].className += "invalid";
             valid=false;
         }
         else
         {
             y["skills"].className += "valid";
         }




         

    }
    if(currentTab==2)
    {
       console.log("dgfsd");
    }
    if (valid)
    {
        document.getElementsByClassName("step")[currentTab].className += " finish";
    }
    return valid; // return the valid status
}

function fixStepIndicator(n) {
    // This function removes the "active" class of all steps...
    var i, x = document.getElementsByClassName("step");

    for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
    }
    //... and adds the "active" class on the current step:
    x[n].className += " active";

}


function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}
function isFutureDate(date)
{
    var date=new Date(date)

    var currentDate = new Date();

    if(date > currentDate)
        return true;

    return false;
}
function isYear(year)
{
    if(year.length==4 || isNaN(year) || year=="")
        return true;

    return false
}
function numberLength(number)
{
    if(number.length>2 || isNaN(number) || number=="")
        return true;

    return false;
}
function stringLengthAndEmpty(string)
{
    if(string.length>=50 || string=="")
        return true;

    return false;

}
function isEdLtSd(startdate,enddate)
{

    if(startdate > enddate)
        return true;
    return false;
}


















/*$(document).ready(function(){

    $("nextBtn").click(function(){
        if(currentTab==0){
            alert("coming");
        }
            });






});*/