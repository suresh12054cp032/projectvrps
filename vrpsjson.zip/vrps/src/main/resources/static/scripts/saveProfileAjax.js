$(document).ready(function () {

    $("#regForm").submit(function (event) {

        //stop submit the form, we will post it manually.
        event.preventDefault();

        fire_ajax_submit();
        alert("Hello! I am an alert box!!");

    });

});

function fire_ajax_submit() {
   
	//personal
    var fullName = $("#name").val();
    var dob= $("#dob").val();
    var gender = $("#gender").val();
    var mobile = $("#mobile").val();
    var email = $("#email").val();
    var address = $("#address").val();
    console.log(fullName);
    console.log($("#mobile").val())
    //work
    var experience=$("#experience").val();
    var location=$("#location").val();
    var projectStatus=$("#projectStatus").val();
    var skills=$("#skills").val();
    
    $("#nextBtn").prop("disabled", true);

    var personal={
    		"personalId":"1",
    		"name":fullName,
    		"dob":	dob,
    		"gender":gender,
    		"email":email,
    		"mobile":mobile,
    		"address":address,
    		"employeeId":"1001"
    }
    
    var work={
    		"experience" : experience,
    		"location" : location,
    		"projectStatus" : projectStatus,
    		"skills" : skills
    }
 var Education={
    		
    }
 var Company={
    		
    }
    var cmdobjec={
    	
    		objpersonal:Personal,
    		objwork:work
    		//objedu:Education,
    		//objcmpy:Company	
    }
    
    
    $.ajax({
    	
        type: "POST",
        contentType: "application/json",
        url: "/saveEduDetails",
        data: JSON.stringify(cmdobjec),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {

        	console.log("Hello world! ajax");
        	$("#feedback tr").remove();
        	var $tr = $('<tr>');
        	 $.each(data, function(i, item) {
        		
        		 $tr.append(
        	            $('<td>').text(item)
        	        ); //.appendTo('#records_table');
        	       
        	    });
        	 $('#feedback').append($tr);
        	 
            $("#nextBtn").prop("disabled", false);

        },
        error: function (e) {

            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#feedback').html(json);

            console.log("ERROR : ", e);
            $("#nextBtn").prop("disabled", false);

        }
    
});
}